package Apppackage;



public class Main {

  
    public static void main(String[] args) {      
      DbConnect connect = new DbConnect();
      connect.getData();
     
    }
    
}
